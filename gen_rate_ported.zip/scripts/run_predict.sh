python main.py predict --test_csv /path/to/test.csv --model_dir ./models --out_csv ./outputs/preds.csv
