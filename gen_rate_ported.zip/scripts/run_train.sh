python main.py train --train_csv /path/to/train.csv --out_dir ./models
